using Microsoft.EntityFrameworkCore;
using WindowFormsDemo2.Models;

namespace WindowFormsDemo2.DataAccess
{
    public class AppDbContext : DbContext
    {
        public DbSet<Product> Products { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            // For demo, using SQLite with a file in the project directory
            optionsBuilder.UseSqlite("Data Source=products.db");
        }
    }
}