using System.Collections.Generic;
using System.Threading.Tasks;
using WindowFormsDemo2.Models;

namespace WindowFormsDemo2.DataAccess
{
    public interface IProductRepository
    {
        Task<IEnumerable<Product>> GetAllAsync();
        Task<Product> GetByIdAsync(int id);
        Task<IEnumerable<Product>> SearchAsync(string searchTerm);
        Task AddAsync(Product product);
        Task UpdateAsync(Product product);
        Task DeleteAsync(int id);
    }
}