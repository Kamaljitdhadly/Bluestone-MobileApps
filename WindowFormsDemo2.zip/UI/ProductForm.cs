using WindowFormsDemo2.BusinessLogic;
using WindowFormsDemo2.Models;

namespace WindowFormsDemo2.UI
{
    public partial class ProductForm : Form
    {
        private readonly IProductService _productService;
        private readonly Product? _existingProduct;

        public ProductForm(IProductService productService, Product? product = null)
        {
            InitializeComponent();
            _productService = productService;
            _existingProduct = product;

            if (_existingProduct != null)
            {
                LoadProductData();
                Text = "Edit Product";
            }
            else
            {
                Text = "Add Product";
            }
        }

        private void LoadProductData()
        {
            if (_existingProduct != null)
            {
                txtName.Text = _existingProduct.Name;
                txtDescription.Text = _existingProduct.Description;
                numPrice.Value = _existingProduct.Price;
                numStock.Value = _existingProduct.StockQuantity;
            }
        }

        private async void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                var product = _existingProduct ?? new Product();

                product.Name = txtName.Text.Trim();
                product.Description = txtDescription.Text.Trim();
                product.Price = numPrice.Value;
                product.StockQuantity = (int)numStock.Value;

                if (_existingProduct == null)
                {
                    await _productService.AddProductAsync(product);
                }
                else
                {
                    await _productService.UpdateProductAsync(product);
                }

                DialogResult = DialogResult.OK;
                Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error saving product: {ex.Message}", "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
            Close();
        }
    }
}