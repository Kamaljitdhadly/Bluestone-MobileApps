using WindowFormsDemo2.BusinessLogic;
using WindowFormsDemo2.Models;

namespace WindowFormsDemo2.UI
{
    public partial class MainForm : Form
    {
        private readonly IProductService _productService;
        private BindingSource _bindingSource;

        public MainForm(IProductService productService)
        {
            InitializeComponent();
            _productService = productService;
            _bindingSource = new BindingSource();
            InitializeDataGridView();
            LoadProductsAsync();
        }

        private void InitializeDataGridView()
        {
            dataGridViewProducts.AutoGenerateColumns = false;
            dataGridViewProducts.DataSource = _bindingSource;

            // Add columns
            dataGridViewProducts.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = "Id",
                HeaderText = "ID",
                Width = 50
            });

            dataGridViewProducts.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = "Name",
                HeaderText = "Name",
                Width = 150
            });

            dataGridViewProducts.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = "Description",
                HeaderText = "Description",
                Width = 200
            });

            dataGridViewProducts.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = "Price",
                HeaderText = "Price",
                Width = 100,
                DefaultCellStyle = new DataGridViewCellStyle { Format = "C2" }
            });

            dataGridViewProducts.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = "StockQuantity",
                HeaderText = "Stock",
                Width = 80
            });
        }

        private async void LoadProductsAsync()
        {
            try
            {
                var products = await _productService.GetAllProductsAsync();
                _bindingSource.DataSource = products;
                UpdateStatus("Products loaded successfully");
            }
            catch (Exception ex)
            {
                UpdateStatus($"Error loading products: {ex.Message}", true);
            }
        }

        private async void btnAdd_Click(object sender, EventArgs e)
        {
            var addForm = new ProductForm(_productService, null);
            if (addForm.ShowDialog() == DialogResult.OK)
            {
                LoadProductsAsync();
                UpdateStatus("Product added successfully");
            }
        }

        private async void btnEdit_Click(object sender, EventArgs e)
        {
            if (dataGridViewProducts.CurrentRow?.DataBoundItem is Product selectedProduct)
            {
                var editForm = new ProductForm(_productService, selectedProduct);
                if (editForm.ShowDialog() == DialogResult.OK)
                {
                    LoadProductsAsync();
                    UpdateStatus("Product updated successfully");
                }
            }
            else
            {
                UpdateStatus("Please select a product to edit", true);
            }
        }

        private async void btnDelete_Click(object sender, EventArgs e)
        {
            if (dataGridViewProducts.CurrentRow?.DataBoundItem is Product selectedProduct)
            {
                var result = MessageBox.Show($"Are you sure you want to delete '{selectedProduct.Name}'?",
                    "Confirm Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                if (result == DialogResult.Yes)
                {
                    try
                    {
                        await _productService.DeleteProductAsync(selectedProduct.Id);
                        LoadProductsAsync();
                        UpdateStatus("Product deleted successfully");
                    }
                    catch (Exception ex)
                    {
                        UpdateStatus($"Error deleting product: {ex.Message}", true);
                    }
                }
            }
            else
            {
                UpdateStatus("Please select a product to delete", true);
            }
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            LoadProductsAsync();
        }

        private async void txtSearch_TextChanged(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtSearch.Text))
            {
                LoadProductsAsync();
            }
            else
            {
                try
                {
                    var products = await _productService.SearchProductsAsync(txtSearch.Text);
                    _bindingSource.DataSource = products;
                }
                catch (Exception ex)
                {
                    UpdateStatus($"Error searching products: {ex.Message}", true);
                }
            }
        }

        private void UpdateStatus(string message, bool isError = false)
        {
            lblStatus.Text = message;
            lblStatus.ForeColor = isError ? Color.Red : Color.Green;
        }
    }
}