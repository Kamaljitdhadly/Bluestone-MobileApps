using System.Collections.Generic;
using System.Threading.Tasks;
using WindowFormsDemo2.Models;

namespace WindowFormsDemo2.BusinessLogic
{
    public interface IProductService
    {
        Task<IEnumerable<Product>> GetAllProductsAsync();
        Task<Product> GetProductByIdAsync(int id);
        Task<IEnumerable<Product>> SearchProductsAsync(string searchTerm);
        Task AddProductAsync(Product product);
        Task UpdateProductAsync(Product product);
        Task DeleteProductAsync(int id);
        Task<bool> ValidateProductAsync(Product product);
    }
}