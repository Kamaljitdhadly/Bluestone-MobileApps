using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using WindowFormsDemo2.DataAccess;
using WindowFormsDemo2.Models;

namespace WindowFormsDemo2.BusinessLogic
{
    public class ProductService : IProductService
    {
        private readonly IProductRepository _productRepository;
        private readonly ILogger<ProductService> _logger;

        public ProductService(IProductRepository productRepository, ILogger<ProductService> logger)
        {
            _productRepository = productRepository;
            _logger = logger;
        }

        public async Task<IEnumerable<Product>> GetAllProductsAsync()
        {
            try
            {
                _logger.LogInformation("Retrieving all products");
                return await _productRepository.GetAllAsync();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error retrieving all products");
                throw;
            }
        }

        public async Task<Product> GetProductByIdAsync(int id)
        {
            try
            {
                _logger.LogInformation("Retrieving product with ID {Id}", id);
                return await _productRepository.GetByIdAsync(id);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error retrieving product with ID {Id}", id);
                throw;
            }
        }

        public async Task<IEnumerable<Product>> SearchProductsAsync(string searchTerm)
        {
            try
            {
                _logger.LogInformation("Searching products with term '{SearchTerm}'", searchTerm);
                return await _productRepository.SearchAsync(searchTerm);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error searching products with term '{SearchTerm}'", searchTerm);
                throw;
            }
        }

        public async Task AddProductAsync(Product product)
        {
            try
            {
                if (!await ValidateProductAsync(product))
                {
                    throw new ValidationException("Product validation failed");
                }

                _logger.LogInformation("Adding new product: {Name}", product.Name);
                await _productRepository.AddAsync(product);
                _logger.LogInformation("Product added successfully");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error adding product: {Name}", product.Name);
                throw;
            }
        }

        public async Task UpdateProductAsync(Product product)
        {
            try
            {
                if (!await ValidateProductAsync(product))
                {
                    throw new ValidationException("Product validation failed");
                }

                _logger.LogInformation("Updating product with ID {Id}", product.Id);
                await _productRepository.UpdateAsync(product);
                _logger.LogInformation("Product updated successfully");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error updating product with ID {Id}", product.Id);
                throw;
            }
        }

        public async Task DeleteProductAsync(int id)
        {
            try
            {
                _logger.LogInformation("Deleting product with ID {Id}", id);
                await _productRepository.DeleteAsync(id);
                _logger.LogInformation("Product deleted successfully");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error deleting product with ID {Id}", id);
                throw;
            }
        }

        public async Task<bool> ValidateProductAsync(Product product)
        {
            var validationResults = new List<ValidationResult>();
            var validationContext = new ValidationContext(product);

            bool isValid = Validator.TryValidateObject(product, validationContext, validationResults, true);

            if (!isValid)
            {
                foreach (var result in validationResults)
                {
                    _logger.LogWarning("Validation error: {ErrorMessage}", result.ErrorMessage);
                }
            }

            return isValid;
        }
    }
}