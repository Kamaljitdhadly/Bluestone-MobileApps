using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using WindowFormsDemo2.BusinessLogic;
using WindowFormsDemo2.DataAccess;
using WindowFormsDemo2.UI;

namespace WindowFormsDemo2;

static class Program
{
    private static IServiceProvider? _serviceProvider;

    /// <summary>
    ///  The main entry point for the application.
    /// </summary>
    [STAThread]
    static void Main()
    {
        // To customize application configuration such as set high DPI settings or default font,
        // see https://aka.ms/applicationconfiguration.
        ApplicationConfiguration.Initialize();

        // Setup dependency injection
        var services = new ServiceCollection();
        ConfigureServices(services);
        _serviceProvider = services.BuildServiceProvider();

        // Run the main form
        var mainForm = _serviceProvider.GetRequiredService<MainForm>();
        Application.Run(mainForm);
    }

    private static void ConfigureServices(IServiceCollection services)
    {
        // Add logging
        services.AddLogging(configure => configure.AddConsole());

        // Add DbContext
        services.AddDbContext<AppDbContext>();

        // Add repositories
        services.AddScoped<IProductRepository, ProductRepository>();

        // Add services
        services.AddScoped<IProductService, ProductService>();

        // Add forms
        services.AddTransient<MainForm>();
    }

    public static T GetService<T>() where T : class
    {
        return _serviceProvider?.GetRequiredService<T>() ?? throw new InvalidOperationException("Service provider not initialized");
    }
}