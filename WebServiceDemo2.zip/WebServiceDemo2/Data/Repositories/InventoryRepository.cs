using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using Data.Interfaces;
using Models.dto;

namespace Data.Repositories
{
    public class InventoryRepository : IInventoryRepository
    {
        private readonly string _connectionString;

        public InventoryRepository(string connectionString)
        {
            _connectionString = connectionString ?? throw new ArgumentNullException(nameof(connectionString));
        }

        public IEnumerable<InventoryDto> GetAll()
        {
            const string sp = "usp_GetInventoryAll";
            var items = new List<InventoryDto>();

            using (var conn = new SqlConnection(_connectionString))
            using (var cmd = new SqlCommand(sp, conn) { CommandType = CommandType.StoredProcedure })
            {
                conn.Open();
                using (var rdr = cmd.ExecuteReader())
                {
                    while (rdr.Read())
                    {
                        items.Add(Map(rdr));
                    }
                }
            }

            return items;
        }

        public InventoryDto GetById(int id)
        {
            const string sp = "usp_GetInventoryById";
            using (var conn = new SqlConnection(_connectionString))
            using (var cmd = new SqlCommand(sp, conn) { CommandType = CommandType.StoredProcedure })
            {
                cmd.Parameters.AddWithValue("@Id", id);
                conn.Open();

                using (var rdr = cmd.ExecuteReader())
                {
                    if (rdr.Read())
                        return Map(rdr);
                }
            }

            return null;
        }

        public int Create(InventoryDto item)
        {
            const string sp = "usp_CreateInventory";
            using (var conn = new SqlConnection(_connectionString))
            using (var cmd = new SqlCommand(sp, conn) { CommandType = CommandType.StoredProcedure })
            {
                cmd.Parameters.AddWithValue("@Sku", item.Sku);
                cmd.Parameters.AddWithValue("@Name", item.Name);
                cmd.Parameters.AddWithValue("@Quantity", item.Quantity);
                cmd.Parameters.AddWithValue("@UnitPrice", item.UnitPrice);
                cmd.Parameters.Add("@NewId", SqlDbType.Int).Direction = ParameterDirection.Output;

                conn.Open();
                cmd.ExecuteNonQuery();

                return Convert.ToInt32(cmd.Parameters["@NewId"].Value);
            }
        }

        public bool Update(InventoryDto item)
        {
            const string sp = "usp_UpdateInventory";
            using (var conn = new SqlConnection(_connectionString))
            using (var cmd = new SqlCommand(sp, conn) { CommandType = CommandType.StoredProcedure })
            {
                cmd.Parameters.AddWithValue("@Id", item.Id);
                cmd.Parameters.AddWithValue("@Sku", item.Sku);
                cmd.Parameters.AddWithValue("@Name", item.Name);
                cmd.Parameters.AddWithValue("@Quantity", item.Quantity);
                cmd.Parameters.AddWithValue("@UnitPrice", item.UnitPrice);

                conn.Open();
                var rows = cmd.ExecuteNonQuery();
                return rows > 0;
            }
        }

        public bool Delete(int id)
        {
            const string sp = "usp_DeleteInventory";
            using (var conn = new SqlConnection(_connectionString))
            using (var cmd = new SqlCommand(sp, conn) { CommandType = CommandType.StoredProcedure })
            {
                cmd.Parameters.AddWithValue("@Id", id);
                conn.Open();
                var rows = cmd.ExecuteNonQuery();
                return rows > 0;
            }
        }

        private static InventoryDto Map(SqlDataReader rdr)
        {
            return new InventoryDto
            {
                Id = rdr.GetInt32(rdr.GetOrdinal("Id")),
                Sku = rdr.GetString(rdr.GetOrdinal("Sku")),
                Name = rdr.GetString(rdr.GetOrdinal("Name")),
                Quantity = rdr.GetInt32(rdr.GetOrdinal("Quantity")),
                UnitPrice = rdr.GetDecimal(rdr.GetOrdinal("UnitPrice")),
                LastUpdated = rdr.GetDateTime(rdr.GetOrdinal("LastUpdated"))
            };
        }
    }
}