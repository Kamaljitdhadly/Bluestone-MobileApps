using System.Collections.Generic;
using Models.dto;

namespace Data.Interfaces
{
    public interface IInventoryRepository
    {
        IEnumerable<InventoryDto> GetAll();
        InventoryDto GetById(int id);
        int Create(InventoryDto item);
        bool Update(InventoryDto item);
        bool Delete(int id);
    }
}