using System;
using System.IO;
using System.Web;
using System.Web.Services.Protocols;

namespace Infrastructure.Security
{
    [AttributeUsage(AttributeTargets.Method)]
    public class ApiKeyAuthorizeAttribute : SoapExtensionAttribute
    {
        public override Type ExtensionType => typeof(ApiKeySoapExtension);
        public override int Priority { get; set; }
    }

    public class ApiKeySoapExtension : SoapExtension
    {
        private const string ApiKeyHeaderName = "X-API-KEY";
        private const string ValidKey = "ReplaceWithRealKey";

        public override object GetInitializer(LogicalMethodInfo methodInfo, SoapExtensionAttribute attribute) => null;
        public override object GetInitializer(Type serviceType) => null;
        public override void Initialize(object initializer) { }

        public override Stream ChainStream(Stream stream)
        {
            return stream;
        }

        public override void ProcessMessage(SoapMessage message)
        {
            if (message.Stage == SoapMessageStage.BeforeDeserialize)
            {
                var request = HttpContext.Current.Request;
                var key = request.Headers[ApiKeyHeaderName];
                if (string.IsNullOrWhiteSpace(key) || !key.Equals(ValidKey, StringComparison.Ordinal))
                {
                    throw new SoapException("Unauthorized", SoapException.ClientFaultCode);
                }
            }
        }
    }
}