using System;

namespace Infrastructure.Logging
{
    public class Logger
    {
        private static readonly Lazy<Logger> _instance = new Lazy<Logger>(() => new Logger());
        public static Logger Instance => _instance.Value;

        private Logger() { }

        public void Info(string message) => Write("INFO", message);
        public void Warn(string message) => Write("WARN", message);
        public void Error(Exception ex, string message = null) => Write("ERROR", $"{message}: {ex}");

        private void Write(string level, string msg)
        {
            System.Diagnostics.Trace.WriteLine($"{DateTime.UtcNow:o} [{level}] {msg}");
        }
    }
}