using Models.dto;

namespace Infrastructure.Helpers
{
    public static class ValidationHelper
    {
        public static ApiResult<bool> Validate(InventoryDto item, bool isUpdate = false)
        {
            if (item == null)
                return new ApiResult<bool> { Success = false, Message = "Payload is required" };

            if (isUpdate && item.Id <= 0)
                return new ApiResult<bool> { Success = false, Message = "Id is required for update" };

            if (string.IsNullOrWhiteSpace(item.Sku))
                return new ApiResult<bool> { Success = false, Message = "SKU is required" };

            if (string.IsNullOrWhiteSpace(item.Name))
                return new ApiResult<bool> { Success = false, Message = "Name is required" };

            if (item.Quantity < 0)
                return new ApiResult<bool> { Success = false, Message = "Quantity cannot be negative" };

            if (item.UnitPrice < 0)
                return new ApiResult<bool> { Success = false, Message = "UnitPrice cannot be negative" };

            return new ApiResult<bool> { Success = true };
        }

        public static ApiResult<T> ToResult<T>(this ApiResult<bool> validationResult)
        {
            return new ApiResult<T>
            {
                Success = validationResult.Success,
                Message = validationResult.Message,
                Data = default
            };
        }
    }
}