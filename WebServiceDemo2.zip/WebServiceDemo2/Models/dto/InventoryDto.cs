using System;
using System.Xml.Serialization;

namespace Models.dto
{
    [Serializable]
    [XmlRoot("Inventory")]
    public class InventoryDto
    {
        public int Id { get; set; }
        public string Sku { get; set; }
        public string Name { get; set; }
        public int Quantity { get; set; }
        public decimal UnitPrice { get; set; }
        public DateTime LastUpdated { get; set; }
    }
}