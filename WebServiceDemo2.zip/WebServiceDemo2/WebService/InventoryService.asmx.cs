using System;
using System.Collections.Generic;
using System.Web.Services;
using System.Web.Script.Services;
using Business.Interfaces;
using Business.Services;
using Models.dto;
using Infrastructure.Logging;
using Infrastructure.Security;

namespace WebService
{
    [WebService(Namespace = "http://example.com/inventory")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    [ScriptService]
    public class InventoryService : System.Web.Services.WebService
    {
        private readonly IInventoryService _inventoryService;
        private readonly Logger _logger = Logger.Instance;

        public InventoryService()
            : this(new Business.Services.InventoryService(new Data.Repositories.InventoryRepository(System.Configuration.ConfigurationManager.ConnectionStrings["Default"].ConnectionString)))
        {
        }

        public InventoryService(IInventoryService inventoryService)
        {
            _inventoryService = inventoryService ?? throw new ArgumentNullException(nameof(inventoryService));
        }

        [WebMethod]
        [ApiKeyAuthorize]
        public ApiResult<IEnumerable<InventoryDto>> GetAllRecords()
        {
            try
            {
                return _inventoryService.GetAll();
            }
            catch (Exception ex)
            {
                _logger.Error(ex, "GetAllRecords failed");
                return new ApiResult<IEnumerable<InventoryDto>> { Success = false, Message = "Internal error" };
            }
        }

        [WebMethod]
        [ApiKeyAuthorize]
        public ApiResult<InventoryDto> GetRecordById(int id)
        {
            try
            {
                return _inventoryService.GetById(id);
            }
            catch (Exception ex)
            {
                _logger.Error(ex, $"GetRecordById failed for id {id}");
                return new ApiResult<InventoryDto> { Success = false, Message = "Internal error" };
            }
        }

        [WebMethod]
        [ApiKeyAuthorize]
        public ApiResult<int> CreateRecord(InventoryDto item)
        {
            try
            {
                return _inventoryService.Create(item);
            }
            catch (Exception ex)
            {
                _logger.Error(ex, "CreateRecord failed");
                return new ApiResult<int> { Success = false, Message = "Internal error" };
            }
        }

        [WebMethod]
        [ApiKeyAuthorize]
        public ApiResult<bool> UpdateRecord(InventoryDto item)
        {
            try
            {
                return _inventoryService.Update(item);
            }
            catch (Exception ex)
            {
                _logger.Error(ex, "UpdateRecord failed");
                return new ApiResult<bool> { Success = false, Message = "Internal error" };
            }
        }

        [WebMethod]
        [ApiKeyAuthorize]
        public ApiResult<bool> DeleteRecord(int id)
        {
            try
            {
                return _inventoryService.Delete(id);
            }
            catch (Exception ex)
            {
                _logger.Error(ex, $"DeleteRecord failed for id {id}");
                return new ApiResult<bool> { Success = false, Message = "Internal error" };
            }
        }
    }
}