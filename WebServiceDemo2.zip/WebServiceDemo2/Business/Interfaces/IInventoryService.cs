using System.Collections.Generic;
using Models.dto;

namespace Business.Interfaces
{
    public interface IInventoryService
    {
        ApiResult<IEnumerable<InventoryDto>> GetAll();
        ApiResult<InventoryDto> GetById(int id);
        ApiResult<int> Create(InventoryDto item);
        ApiResult<bool> Update(InventoryDto item);
        ApiResult<bool> Delete(int id);
    }
}