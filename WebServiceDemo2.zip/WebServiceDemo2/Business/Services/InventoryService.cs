using System;
using System.Collections.Generic;
using System.Linq;
using Business.Interfaces;
using Data.Interfaces;
using Models.dto;
using Infrastructure.Helpers;

namespace Business.Services
{
    public class InventoryService : IInventoryService
    {
        private readonly IInventoryRepository _repo;
        public InventoryService(IInventoryRepository repo)
        {
            _repo = repo ?? throw new ArgumentNullException(nameof(repo));
        }

        public ApiResult<IEnumerable<InventoryDto>> GetAll()
        {
            var data = _repo.GetAll();
            return new ApiResult<IEnumerable<InventoryDto>>
            {
                Success = true,
                Data = data,
                Message = data.Any() ? "OK" : "No records found"
            };
        }

        public ApiResult<InventoryDto> GetById(int id)
        {
            if (id <= 0)
                return new ApiResult<InventoryDto> { Success = false, Message = "ID must be > 0" };

            var item = _repo.GetById(id);
            if (item == null)
                return new ApiResult<InventoryDto> { Success = false, Message = "Item not found" };

            return new ApiResult<InventoryDto> { Success = true, Data = item, Message = "OK" };
        }

        public ApiResult<int> Create(InventoryDto item)
        {
            var validation = ValidationHelper.Validate(item);
            if (!validation.Success)
                return validation.ToResult<int>();

            int newId = _repo.Create(item);
            return new ApiResult<int> { Success = true, Data = newId, Message = "Created successfully" };
        }

        public ApiResult<bool> Update(InventoryDto item)
        {
            var validation = ValidationHelper.Validate(item, true);
            if (!validation.Success)
                return validation.ToResult<bool>();

            bool updated = _repo.Update(item);
            return new ApiResult<bool>
            {
                Success = updated,
                Data = updated,
                Message = updated ? "Updated successfully" : "Record not found"
            };
        }

        public ApiResult<bool> Delete(int id)
        {
            if (id <= 0)
                return new ApiResult<bool> { Success = false, Message = "ID must be > 0" };

            bool deleted = _repo.Delete(id);
            return new ApiResult<bool>
            {
                Success = deleted,
                Data = deleted,
                Message = deleted ? "Deleted successfully" : "Record not found"
            };
        }
    }
}