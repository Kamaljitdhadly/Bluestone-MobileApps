CREATE PROCEDURE usp_UpdateInventory
    @Id INT,
    @Sku NVARCHAR(50),
    @Name NVARCHAR(200),
    @Quantity INT,
    @UnitPrice DECIMAL(18,2)
AS
SET NOCOUNT ON;
UPDATE Inventory
SET Sku = @Sku,
    Name = @Name,
    Quantity = @Quantity,
    UnitPrice = @UnitPrice,
    LastUpdated = GETDATE()
WHERE Id = @Id;
