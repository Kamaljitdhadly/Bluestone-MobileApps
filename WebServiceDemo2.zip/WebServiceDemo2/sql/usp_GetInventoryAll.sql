CREATE PROCEDURE usp_GetInventoryAll AS
SELECT Id, Sku, Name, Quantity, UnitPrice, LastUpdated
FROM Inventory;
