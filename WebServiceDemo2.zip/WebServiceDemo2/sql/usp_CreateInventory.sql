CREATE PROCEDURE usp_CreateInventory
    @Sku NVARCHAR(50),
    @Name NVARCHAR(200),
    @Quantity INT,
    @UnitPrice DECIMAL(18,2),
    @NewId INT OUTPUT
AS
SET NOCOUNT ON;
INSERT INTO Inventory (Sku, Name, Quantity, UnitPrice, LastUpdated)
VALUES (@Sku, @Name, @Quantity, @UnitPrice, GETDATE());
SET @NewId = SCOPE_IDENTITY();
