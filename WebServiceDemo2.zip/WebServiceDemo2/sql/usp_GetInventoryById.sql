CREATE PROCEDURE usp_GetInventoryById @Id INT AS
SELECT Id, Sku, Name, Quantity, UnitPrice, LastUpdated
FROM Inventory
WHERE Id = @Id;
