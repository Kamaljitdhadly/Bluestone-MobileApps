CREATE PROCEDURE usp_DeleteInventory @Id INT AS
DELETE FROM Inventory WHERE Id = @Id;
